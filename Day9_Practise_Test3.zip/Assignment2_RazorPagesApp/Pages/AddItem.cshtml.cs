
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

public class AddItemModel : PageModel
{
    [BindProperty]
    public string NewItem { get; set; }

    public void OnPost()
    {
        if (!string.IsNullOrEmpty(NewItem))
        {
            IndexModel.Items.Add(NewItem);
        }
    }
}
