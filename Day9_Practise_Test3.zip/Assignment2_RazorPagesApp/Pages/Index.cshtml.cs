
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Collections.Generic;

public class IndexModel : PageModel
{
    public static List<string> Items = new List<string> { "Apple", "Banana" };
    public List<string> ItemsList => Items;

    public List<string> Items => ItemsList;
}
